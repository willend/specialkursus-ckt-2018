Version: 2.0
(c) E.Farhi, ILL. License: EUPL.

These libraries can be used independently from the other parts of iFit. 
They provide low level routines for:

- reading files in a large set of formats
- optimizing methods
